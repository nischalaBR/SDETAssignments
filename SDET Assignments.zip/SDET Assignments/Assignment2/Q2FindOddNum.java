package Assign2;

import java.util.Scanner;

public class Q2FindOddNum {

	public static void main(String[] args) {
		int number, odd;
		Scanner sc = new Scanner(System.in);

		System.out.print("Enter the limit: ");
		number = sc.nextInt();
		sc.close();

		odd = 79;
		System.out.print("List of odd numbers: ");

		while (odd <= number) {

			System.out.print(odd + " ");

			odd = odd + 2;
		}
	}
}
