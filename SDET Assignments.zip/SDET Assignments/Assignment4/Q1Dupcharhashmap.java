package Assign4;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Q1Dupcharhashmap {

	public void countDupChars(String str) {

		Map<Character, Integer> map = new HashMap<Character, Integer>();

		char[] chars = str.toCharArray();

		for (Character ch : chars) {
			if (map.containsKey(ch)) {
				map.put(ch, map.get(ch) + 1);
			} else {
				map.put(ch, 1);
			}
		}

		Set<Character> keys = map.keySet();

		for (Character ch : keys) {
			if (map.get(ch) > 1) {
				System.out.println("Char " + ch + " " + map.get(ch));
			}
		}
	}

	public static void main(String a[]) {
		Dupcharhashmap obj = new Dupcharhashmap();
		System.out.println("String: BROADRIDGE.SELENIUM");
		System.out.println("-------------------------");
		obj.countDupChars("BROADRIDGE.SELENIUM");

		System.out.println("\nString: Training");
		System.out.println("-------------------------");
		obj.countDupChars("Training");

		System.out.println("\nString: !$$#&@!!!#@@");
		System.out.println("-------------------------");
		obj.countDupChars("!$$#&@!!!#@@");
	}
}
