package Assign3;

public class Q3Brown {
	public static void main(String[] args) {
		String strOrig = "A brown fox ran away fast";
		int intIndex = strOrig.indexOf("brown");
		if (intIndex == -1) {
			System.out.println("word - brown not found");
		} else {
			System.out.println("Found word - brown at index " + intIndex);
		}
	}
}