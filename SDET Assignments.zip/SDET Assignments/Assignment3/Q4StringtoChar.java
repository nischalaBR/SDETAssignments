package Assign3;

public class Q4StringtoChar {
	public static void main(String[] args) {

		char[] ch = { 'S', 'E', 'L', 'E', 'N', 'I', 'U', 'M' };
		String str = new String(ch);
		System.out.println(str);

		char c[] = str.toCharArray();

		System.out.println("On using toCharArray() method -");

		for (int i = 0; i < c.length; i++) {
			System.out.println(c[i]);

		}
	}
}