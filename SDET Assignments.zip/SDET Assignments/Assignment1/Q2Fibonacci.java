package Assign1;

public class Q2Fibonacci {

	public static void main(String[] args) {

		int number = 10, FN = 0, SN = 1;
		System.out.print("Fibonacci Series of " + number + " values");

		for (int i = 1; i <= number; ++i) {
			System.out.print(FN + " , ");

			int SUM = FN + SN;
			FN = SN;
			SN = SUM;
		}
	}
}
