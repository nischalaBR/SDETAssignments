package Assign1;

import java.util.Scanner;

public class Q1Factorial {

	public static void main(String[] args) {

		int FactNo;

		System.out.println("Input your number and press enter: ");

		Scanner in = new Scanner(System.in);
		FactNo = in.nextInt();
		in.close();

		long firstno = 1;
		int i = 1;
		while (i <= FactNo) {
			firstno = firstno * i;
			i++;
		}
		System.out.println("Factorial of " + FactNo + " is " + firstno);
	}
}