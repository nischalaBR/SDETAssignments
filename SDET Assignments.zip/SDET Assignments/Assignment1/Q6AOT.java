package Assign1;

import java.util.Scanner;

public class Q6AOT {

	public static void main(String args[]) {

		Scanner scan = new Scanner(System.in);

		System.out.println("Enter Height of the Triangle:");
		double height = scan.nextDouble();

		System.out.println("Enter Base of the Triangle:");
		double base = scan.nextDouble();

		double area = (0.5) * (height * base);
		System.out.println("Area of Triangle is: " + area);

		scan.close();
	}

}
